# utils.py
# Localization: Odometry (wheel encoders) + Compass (heading correction)
# Dead-reckoning with compass heading correction every timestep.
#
# Reference: Cyberbotics Webots ROSbot documentation
# https://webots.cloud/run?version=R2023b&url=https://github.com/cyberbotics/
#           webots/blob/released/projects/robots/husarion/rosbot/protos/Rosbot.proto
# Compass x-axis sign (-values[0]) verified by live test on R2025a — June 2025
# Maze: Maze4.wbt — OTH Amberg-Weiden Autonomous Robots
#
# Start pose for Maze 4:
#   translation -2.22817 2.79462 0.01
#   rotation    0 0 1 2.618
# All values read from settings.py — no hardcoding here.

import math
from settings import (
    WHEEL_RADIUS,
    AXLE_LENGTH,
    START_X,        # -2.22817  (Maze 4)
    START_Y,        #  2.79462  (Maze 4)
    START_THETA,    #  2.618    (Maze 4)
    TIME_STEP,
)

COMPASS_NAME = "imu compass"    # verified R2025a ROSbot by live discovery


def init_compass(robot):
    """
    Enable the ROSbot compass sensor and return the device handle.

    Parameters
    ----------
    robot : controller.Robot

    Returns
    -------
    Compass device handle, or None if device not found.
    """
    compass = robot.getDevice(COMPASS_NAME)
    if compass is None:
        print(f"[utils] WARNING — compass '{COMPASS_NAME}' not found. "
              "Heading will rely on odometry only.")
        return None
    compass.enable(TIME_STEP)
    print(f"[utils] Compass '{COMPASS_NAME}' enabled.")
    return compass


def compass_heading(compass) -> float:
    """
    Read the ROSbot compass and return heading in radians [-pi, pi].

    Webots ENU frame: North = +Y axis.
    Formula: atan2(-x, y)

    The x component is negated because the ROSbot R2025a compass
    returns a flipped x-axis — verified by live test:
      atan2( x, y) → -99.1°  for a true +99.1° pose
      atan2(-x, y) → +99.1°  correct

    Returns
    -------
    float : heading in radians. 0 = East (+X), pi/2 = North (+Y).
    """
    values  = compass.getValues()          # [x, y, z]
    heading = math.atan2(-values[0], values[1])
    return heading


class Odometry:
    """
    Tracks robot pose (x, y, theta) using wheel encoder deltas.
    Compass replaces theta every timestep — prevents heading drift.

    Maze 4 start: (-2.22817, 2.79462, 2.618 rad)
    All start values read from settings.py.

    Usage
    -----
        odom = Odometry()
        # each timestep:
        enc_left  = avg(fl_encoder, rl_encoder)
        enc_right = avg(fr_encoder, rr_encoder)
        odom.update(enc_left, enc_right, compass)
        x, y, theta = odom.x, odom.y, odom.theta
    """

    def __init__(self):
        self.x     = START_X       # m  — -2.22817 for Maze 4
        self.y     = START_Y       # m  —  2.79462 for Maze 4
        self.theta = START_THETA   # rad — 2.618 for Maze 4
                                   #       overridden by compass on first update

        self._prev_left  = None    # seeded on first update() call
        self._prev_right = None

        print(f"[utils] Odometry initialised — Maze 4")
        print(f"        start=({self.x:.3f}, {self.y:.3f}), "
              f"θ={math.degrees(self.theta):.1f}°")

    def update(self, enc_left: float, enc_right: float, compass=None):
        """
        Update pose from new encoder readings + optional compass.

        On the very first call: seeds encoder baselines and reads
        compass as ground-truth heading (avoids START_THETA sign issues).

        Parameters
        ----------
        enc_left  : float — averaged left  encoder value (rad)
        enc_right : float — averaged right encoder value (rad)
        compass   : Compass device handle or None
        """
        # ── First call: seed baselines, grab real heading ─────────────
        if self._prev_left is None:
            self._prev_left  = enc_left
            self._prev_right = enc_right
            if compass is not None:
                self.theta = compass_heading(compass)
                print(f"[utils] Compass seed heading: "
                      f"{math.degrees(self.theta):.1f}°")
            return

        # ── Encoder deltas → wheel distances (m) ─────────────────────
        d_left  = (enc_left  - self._prev_left)  * WHEEL_RADIUS
        d_right = (enc_right - self._prev_right) * WHEEL_RADIUS

        self._prev_left  = enc_left
        self._prev_right = enc_right

        # ── Arc model — mid-point integration ─────────────────────────
        d_center = (d_right + d_left)  / 2.0
        d_theta  = (d_right - d_left)  / AXLE_LENGTH

        # ── Heading: compass = ground truth, odometry = fallback ──────
        if compass is not None:
            self.theta = compass_heading(compass)
        else:
            self.theta = _wrap_angle(self.theta + d_theta)

        # ── Position update (mid-point rule) ──────────────────────────
        mid_theta = self.theta - d_theta / 2.0
        self.x   += d_center * math.cos(mid_theta)
        self.y   += d_center * math.sin(mid_theta)

    @property
    def pose(self):
        """Return (x, y, theta) as a tuple."""
        return (self.x, self.y, self.theta)

    def __str__(self):
        return (f"Pose(x={self.x:.3f} m, y={self.y:.3f} m, "
                f"θ={math.degrees(self.theta):.1f}°)")


# ── Geometry helpers ──────────────────────────────────────────────────────────
def _wrap_angle(angle: float) -> float:
    """Normalise angle to [-pi, pi]."""
    return math.atan2(math.sin(angle), math.cos(angle))


def angle_to_goal(ox: float, oy: float, gx: float, gy: float) -> float:
    """
    Bearing from robot position (ox, oy) to goal (gx, gy).
    Returns radians in [-pi, pi].
    """
    return math.atan2(gy - oy, gx - ox)


def distance_to_goal(ox: float, oy: float, gx: float, gy: float) -> float:
    """Euclidean distance from robot to goal (metres)."""
    return math.hypot(gx - ox, gy - oy)


def heading_error(current_theta: float, target_theta: float) -> float:
    """
    Signed heading error in [-pi, pi].
    Positive = robot must turn left (counter-clockwise).
    """
    return _wrap_angle(target_theta - current_theta)