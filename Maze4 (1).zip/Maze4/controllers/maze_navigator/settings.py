# settings.py
# All magic numbers for Maze 4 in one place
# Values extracted directly from Maze4.wbt

# ── Simulation ───────────────────────────────────────────
TIME_STEP = 64                  # ms

# ── Robot physical parameters ────────────────────────────
ROBOT_RADIUS   = 0.15           # m
MAX_SPEED      = 6.28           # rad/s
WHEEL_RADIUS   = 0.04           # m
AXLE_LENGTH    = 0.217          # m

# ── Starting pose (from Maze4.wbt) ───────────────────────
START_X     = -2.22817          # m
START_Y     =  2.79462          # m
START_THETA =  2.618            # rad

# ── Waypoints: START → BLUE → YELLOW (timer stops) ───────
WAYPOINT_1_X =  0.44            # m  BlueCylinder
WAYPOINT_1_Y =  0.04            # m
WAYPOINT_2_X = -2.73            # m  YellowCylinder
WAYPOINT_2_Y =  3.13            # m
GOAL_RADIUS  =  0.20            # m  arrival tolerance

# ── Wall geometry ─────────────────────────────────────────
# WallShort: 0.5 x 0.05 m
WALL_SHORT_LENGTH    = 0.5
WALL_SHORT_THICKNESS = 0.05
# WallMedium: 1.0 x 0.05 m
WALL_MEDIUM_LENGTH   = 1.0
WALL_MEDIUM_THICKNESS= 0.05

# ── Poison zone (single green box) ───────────────────────
POISON_ZONES = [
    {"cx": -0.810, "cy": 0.662, "half_w": 0.5, "half_h": 0.25, "angle": 2.35619},
]
POISON_MARGIN = 0.05            # m extra clearance (keep small — avoids sealing corridors)

# ── Occupancy grid ────────────────────────────────────────
GRID_RESOLUTION    = 0.05       # m per cell
GRID_X_MIN         = -5.0       # m  (maze extends further left in Maze4)
GRID_X_MAX         =  1.5       # m
GRID_Y_MIN         = -2.5       # m
GRID_Y_MAX         =  4.5       # m
GRID_INFLATE_RADIUS= 2          # cells (0.10 m clearance)

# ── Pathfinder (A*) ───────────────────────────────────────
ASTAR_DIAGONAL = True

# ── Navigator ─────────────────────────────────────────────
NAV_LINEAR_KP          = 4.0    # proportional gain, forward speed
NAV_ANGULAR_KP         = 6.0    # proportional gain, turning
NAV_WAYPOINT_TOLERANCE = 0.12   # m
NAV_HEADING_TOLERANCE  = 0.05   # rad

# ── Sensors ───────────────────────────────────────────────
LIDAR_RANGE_MAX  = 3.5          # m
LIDAR_ANGLE_MIN  = -1.5708      # rad
LIDAR_ANGLE_MAX  =  1.5708      # rad