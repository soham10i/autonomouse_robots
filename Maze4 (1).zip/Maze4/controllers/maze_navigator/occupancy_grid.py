# occupancy_grid.py
# OccupancyGrid class — static map built from known .wbt geometry.
# 300x300 grid, log-odds updates, obstacle inflation, poison zones.
# Pygame visualisation on main thread (no threading).
#
# Log-odds occupancy grid algorithm:
# Thrun, S., Burgard, W., Fox, D. (2005). Probabilistic Robotics.
# MIT Press. Chapter 4.2 (Binary Bayes Filter / occupancy grid mapping).

import math
import numpy as np
from settings import (
    GRID_RESOLUTION,
    GRID_X_MIN, GRID_X_MAX,
    GRID_Y_MIN, GRID_Y_MAX,
    GRID_INFLATE_RADIUS,
    ROBOT_RADIUS,
    POISON_ZONES, POISON_MARGIN,
    LIDAR_RANGE_MAX,
)

# ── Log-odds constants ────────────────────────────────────────────────────────
_L_OCC  =  0.85   # log-odds added when a cell is seen as occupied
_L_FREE = -0.40   # log-odds added when a cell is seen as free
_L_MIN  = -2.0    # clamp floor
_L_MAX  =  3.5    # clamp ceiling
_L_THRESH = 0.5   # above this → treat as obstacle for path planning

# ── Grid dimensions — computed from world bounds and resolution ───────────────
# Maze 4: x=[-5.0, 1.5] → 130 cols,  y=[-2.5, 4.5] → 140 rows
import math as _math
from settings import GRID_X_MIN as _X_MIN, GRID_X_MAX as _X_MAX
from settings import GRID_Y_MIN as _Y_MIN, GRID_Y_MAX as _Y_MAX
from settings import GRID_RESOLUTION as _RES_BOOT
_COLS = _math.ceil((_X_MAX - _X_MIN) / _RES_BOOT)   # 130 for Maze 4
_ROWS = _math.ceil((_Y_MAX - _Y_MIN) / _RES_BOOT)   # 140 for Maze 4


class OccupancyGrid:
    """
    300x300 log-odds occupancy grid covering the Maze 5 arena.

    Coordinate conventions
    ----------------------
    World  : x right, y up  (Webots ENU)
    Grid   : col = x-axis, row = y-axis (row 0 = GRID_Y_MIN)

    Usage
    -----
        grid = OccupancyGrid()
        grid.build_static_map()          # paint walls + poison from .wbt
        grid.update_from_lidar(ranges, angles, robot_x, robot_y, robot_theta)
        path = grid.is_free(gx, gy)      # query a world cell
        grid.render(robot_x, robot_y, path)   # pygame draw
    """

    def __init__(self):
        # Log-odds grid — float32, starts all-FREE (zero)
        # Unknown space treated as navigable (optimistic planning)
        self._log_odds = np.zeros((_ROWS, _COLS), dtype=np.float32)

        # Inflated obstacle mask — populated by build_static_map()
        # Separate from log_odds so lidar updates don't affect planning mask
        self._inflated_mask = np.zeros((_ROWS, _COLS), dtype=bool)

        # Frontier blacklist — set of (col, row) grid centroids A* cannot reach
        self._frontier_blacklist = set()

        # Precomputed cell size
        self._res  = GRID_RESOLUTION
        self._cols = _COLS
        self._rows = _ROWS

        # Pygame surface (created lazily on first render call)
        self._screen = None
        self._cell_px = None   # pixel size per cell

        print(f"[occupancy_grid] Grid {_COLS}x{_ROWS}, "
              f"res={GRID_RESOLUTION} m/cell, "
              f"world=[{GRID_X_MIN},{GRID_X_MAX}]x[{GRID_Y_MIN},{GRID_Y_MAX}]")

    # ── Coordinate conversion ─────────────────────────────────────────────────
    def world_to_grid(self, wx: float, wy: float):
        """World (m) → (col, row) integers. Returns None if out of bounds."""
        col = int((wx - GRID_X_MIN) / self._res)
        row = int((wy - GRID_Y_MIN) / self._res)
        if 0 <= col < self._cols and 0 <= row < self._rows:
            return col, row
        return None

    def grid_to_world(self, col: int, row: int):
        """Grid (col, row) → world centre (wx, wy) in metres."""
        wx = GRID_X_MIN + (col + 0.5) * self._res
        wy = GRID_Y_MIN + (row + 0.5) * self._res
        return wx, wy

    # ── Log-odds helpers ──────────────────────────────────────────────────────
    def _set_occupied(self, col: int, row: int):
        if 0 <= col < self._cols and 0 <= row < self._rows:
            self._log_odds[row, col] = np.clip(
                self._log_odds[row, col] + _L_OCC, _L_MIN, _L_MAX)

    def _set_free(self, col: int, row: int):
        if 0 <= col < self._cols and 0 <= row < self._rows:
            self._log_odds[row, col] = np.clip(
                self._log_odds[row, col] + _L_FREE, _L_MIN, _L_MAX)

    def _force_occupied(self, col: int, row: int):
        """Hard-set a cell to maximum occupancy (used for static map)."""
        if 0 <= col < self._cols and 0 <= row < self._rows:
            self._log_odds[row, col] = _L_MAX

    def is_free(self, wx: float, wy: float) -> bool:
        """
        Return True if world position is free for path planning.
        Queries _inflated_mask (static obstacles + inflation).
        Unknown space = FREE (optimistic planning).
        """
        cell = self.world_to_grid(wx, wy)
        if cell is None:
            return False
        col, row = cell
        return not self._inflated_mask[row, col]

    def is_free_grid(self, col: int, row: int) -> bool:
        """Return True if grid cell is free for path planning."""
        if not (0 <= col < self._cols and 0 <= row < self._rows):
            return False
        return not self._inflated_mask[row, col]

    # ── Static map from .wbt ──────────────────────────────────────────────────
    def build_static_map(self):
        """
        Paint all walls and poison zones from Maze5.wbt into the grid
        at maximum log-odds, then inflate obstacles by GRID_INFLATE_RADIUS.
        Called once at startup — no lidar needed.
        """
        self._paint_walls()
        self._paint_poison()
        self._inflate_obstacles()
        print("[occupancy_grid] Static map built and inflated.")

    def _paint_walls(self):
        """Rasterise every wall segment from Maze4.wbt into the grid."""
        # Wall data extracted directly from Maze4.wbt
        # Format: (cx, cy, angle_rad, half_length)
        # WallShort: 0.5 x 0.05 m  |  WallMedium: 1.0 x 0.05 m
        ANGLE_A =  1.83259    # WallMedium diagonal group A
        ANGLE_B = -0.26180    # WallMedium diagonal group B
        ANGLE_C =  0.26180    # WallShort/WallMedium group C
        ANGLE_D = -0.78540    # WallShort -45 deg
        ANGLE_E =  1.57080    # WallShort/WallMedium 90 deg
        ANGLE_F =  1.83260    # WallShort ~same as A

        HALF_M = 0.5     # WallMedium half-length (1.0 m total)
        HALF_S = 0.25    # WallShort  half-length (0.5 m total)
        HALF_T = 0.025   # all walls thickness half (0.05 m total)

        walls = [
            # ── WallMedium (1.0 x 0.05) ──────────────────────────────
            (-2.86610,  2.87811, ANGLE_A, HALF_M),   # WallMedium(1)
            (-2.61504,  1.94112, ANGLE_A, HALF_M),   # WallMedium(2)
            (-2.35882,  0.98484, ANGLE_A, HALF_M),   # WallMedium(3)
            (-2.69053,  0.36799, ANGLE_B, HALF_M),   # WallMedium(4)
            (-2.06437,  3.09295, ANGLE_A, HALF_M),   # WallMedium(5)
            (-1.81331,  2.15593, ANGLE_A, HALF_M),   # WallMedium(6)
            (-1.55709,  1.19966, ANGLE_A, HALF_M),   # WallMedium(7)
            (-3.62749,  0.11694, ANGLE_B, HALF_M),   # WallMedium(11)
            (-4.08749, -0.51306, ANGLE_E, HALF_M),   # WallMedium(12)
            (-4.08749, -1.49306, ANGLE_E, HALF_M),   # WallMedium(13)
            (-3.59173, -1.83649, ANGLE_E, HALF_M),   # WallMedium(14)
            (-2.65537, -1.11970, ANGLE_C, HALF_M),   # WallMedium(15)
            (-1.70877, -0.86606, ANGLE_C, HALF_M),   # WallMedium(16)
            (-0.76215, -0.61242, ANGLE_C, HALF_M),   # WallMedium(17)
            ( 0.19412, -0.35621, ANGLE_C, HALF_M),   # WallMedium(21)
            (-2.15435, -0.35799, ANGLE_B, HALF_M),   # WallMedium(9)
            (-1.19808, -0.10177, ANGLE_B, HALF_M),   # WallMedium(22)
            (-0.76340,  0.01470, ANGLE_B, HALF_M),   # WallMedium(23)
            ( 0.07695,  0.23987, ANGLE_B, HALF_M),   # WallMedium(18)
            (-3.11064, -0.61422, ANGLE_B, HALF_M),   # WallMedium(10)
            # ── WallShort (0.5 x 0.05) ───────────────────────────────
            (-2.76758,  3.40977, ANGLE_C, HALF_S),   # WallShort(1)
            (-2.42950,  3.50035, ANGLE_C, HALF_S),   # WallShort(2)
            (-2.73784,  2.79654, ANGLE_C, HALF_S),   # WallShort(3)
            (-2.01850,  2.43025, ANGLE_C, HALF_S),   # WallShort(4)
            (-2.47760,  1.74816, ANGLE_C, HALF_S),   # WallShort(5)
            (-1.72152,  1.36062, ANGLE_C, HALF_S),   # WallShort(6)
            (-2.15593,  0.50917, ANGLE_C, HALF_S),   # WallShort(7)
            (-2.23366,  0.30304, ANGLE_D, HALF_S),   # WallShort(8)
            (-2.48116, -0.24143, ANGLE_D, HALF_S),   # WallShort(9)
            (-3.37907,  0.00605, ANGLE_D, HALF_S),   # WallShort(10)
            (-3.30277, -0.78101, ANGLE_C, HALF_S),   # WallShort(11)
            (-3.11719, -1.47737, ANGLE_E, HALF_S),   # WallShort(12)
            (-2.53272, -0.98880, ANGLE_C, HALF_S),   # WallShort(13)
            (-1.92146, -0.41091, ANGLE_C, HALF_S),   # WallShort(14)
            (-1.02689, -0.81307, ANGLE_E, HALF_S),   # WallShort(15)
            (-0.57073,  0.18914, ANGLE_E, HALF_S),   # WallShort(16)
            ( 0.63912,  0.07851, ANGLE_F, HALF_S),   # WallShort(17)
            (-0.91019,  0.85496, ANGLE_E, HALF_S),   # WallShort(18)
        ]

        step = self._res / 2.0      # sample at half-cell resolution

        for cx, cy, angle, half_l in walls:
            cos_a = math.cos(angle)
            sin_a = math.sin(angle)
            ls = np.arange(-half_l, half_l + step, step)
            ts = np.arange(-HALF_T,  HALF_T + step, step)
            for l in ls:
                for t in ts:
                    wx = cx + l * cos_a - t * sin_a
                    wy = cy + l * sin_a + t * cos_a
                    cell = self.world_to_grid(wx, wy)
                    if cell:
                        self._force_occupied(cell[0], cell[1])

    def _paint_poison(self):
        """Mark poison zones (green ground) as occupied + extra margin."""
        # Poison data from Maze5.wbt: size 1.8 x 0.5 m, angle -0.26180
        # POISON_ZONES from settings.py
        half_step = self._res / 2.0

        for zone in POISON_ZONES:
            cx    = zone["cx"]
            cy    = zone["cy"]
            hw    = zone["half_w"] + POISON_MARGIN
            hh    = zone["half_h"] + POISON_MARGIN
            angle = zone["angle"]
            cos_a = math.cos(angle)
            sin_a = math.sin(angle)

            ls = np.arange(-hw, hw + half_step, half_step)
            ts = np.arange(-hh, hh + half_step, half_step)
            for l in ls:
                for t in ts:
                    wx = cx + l * cos_a - t * sin_a
                    wy = cy + l * sin_a + t * cos_a
                    cell = self.world_to_grid(wx, wy)
                    if cell:
                        self._force_occupied(cell[0], cell[1])

    def _inflate_obstacles(self):
        """
        Inflate occupied cells using cv2.dilate with a square kernel
        of side (2*GRID_INFLATE_RADIUS+1).  This gives the same result
        as morphological dilation and is faster than scipy on large grids.

        Design: the inflated grid is written into a SEPARATE array
        (_inflated) so that the live log-odds grid (_log_odds) starts
        all-FREE.  A* therefore treats unknown space as navigable
        (optimistic / open-world planning) while the inflated mask is
        used only as the obstacle layer for path planning.

        Reference: Bradski, G. (2000). The OpenCV Library.
        Dr. Dobb's Journal of Software Tools.
        """
        import cv2

        r = GRID_INFLATE_RADIUS
        kernel = np.ones((2 * r + 1, 2 * r + 1), dtype=np.uint8)

        # Binary mask of walls + poison (uint8 for cv2)
        occupied = (self._log_odds >= _L_THRESH).astype(np.uint8)

        # cv2.dilate expands every occupied pixel by r cells in all directions
        inflated_mask = cv2.dilate(occupied, kernel, iterations=1)

        # ── Key design decision: store inflated mask SEPARATELY ───────────
        # _log_odds stays all-zero (all FREE) so lidar updates are unbiased
        # and A* can explore through unknown space.
        # _inflated_mask is the hard obstacle layer queried by the pathfinder.
        self._inflated_mask = inflated_mask.astype(bool)

        n_obs = int(inflated_mask.sum())
        print(f"[occupancy_grid] cv2.dilate inflation done — {n_obs} obstacle cells "
              f"({100*n_obs/(_ROWS*_COLS):.1f}% of grid)")

        # ── Protect goal cells — never block them even after inflation ────
        self._protect_goal_cells()

    def _protect_goal_cells(self):
        """
        Force-free a small radius around each goal so inflation from
        nearby walls can never block the robot reaching its target.
        """
        from settings import WAYPOINT_1_X, WAYPOINT_1_Y, WAYPOINT_2_X, WAYPOINT_2_Y
        goals = [
            (WAYPOINT_1_X, WAYPOINT_1_Y, "Blue"),    # (0.44, 0.04)
            (WAYPOINT_2_X, WAYPOINT_2_Y, "Yellow"),  # (-2.73, 3.13)
        ]
        protect_r = 2
        for wx, wy, name in goals:
            cell = self.world_to_grid(wx, wy)
            if cell:
                gc, gr = cell
                for dr in range(-protect_r, protect_r + 1):
                    for dc in range(-protect_r, protect_r + 1):
                        r2, c2 = gr + dr, gc + dc
                        if 0 <= r2 < self._rows and 0 <= c2 < self._cols:
                            self._inflated_mask[r2, c2] = False
                print(f"[occupancy_grid] Goal '{name}' ({wx},{wy}) protected free.")

    # ── Lidar update (log-odds ray casting) ───────────────────────────────────
    def update_from_lidar(self, ranges, angles,
                          robot_x: float, robot_y: float, robot_theta: float):
        """
        Update log-odds grid from one lidar scan.

        Each beam is traced cell-by-cell using Bresenham's line algorithm:
          - Every cell along the ray (excluding endpoint) → FREE
          - The endpoint cell (if range < max) → OCCUPIED

        Bresenham's line algorithm:
        Bresenham, J.E. (1965). Algorithm for computer control of a digital
        plotter. IBM Systems Journal, 4(1), 25-30.

        Parameters
        ----------
        ranges      : list/array of range values (m), one per beam
        angles      : list/array of beam angles relative to robot heading (rad)
        robot_x/y   : current robot world position (m)
        robot_theta : current robot heading (rad)
        """
        r_max = LIDAR_RANGE_MAX

        # Robot origin in grid coordinates
        origin = self.world_to_grid(robot_x, robot_y)
        if origin is None:
            return
        oc, or_ = origin

        for rng, ang in zip(ranges, angles):
            # Skip invalid beams
            if rng <= 0 or math.isnan(rng) or math.isnan(ang):
                continue

            hit = rng < r_max

            # Clamp range to grid max
            trace_range = min(rng, r_max)

            # Compute endpoint in world then grid
            beam_angle = robot_theta + ang
            ex = robot_x + trace_range * math.cos(beam_angle)
            ey = robot_y + trace_range * math.sin(beam_angle)
            endpoint = self.world_to_grid(ex, ey)
            if endpoint is None:
                # Beam exits grid — find last in-bounds cell
                endpoint = self._clamp_to_grid(oc, or_, ex, ey)
                if endpoint is None:
                    continue
                hit = False   # clipped beam — no reliable hit

            ec, er = endpoint

            # ── Bresenham line from origin to endpoint ────────────────
            # Reference: Bresenham (1965) IBM Systems Journal 4(1) p.25
            c0, r0 = oc, or_
            c1, r1 = ec, er

            dc = abs(c1 - c0)
            dr = abs(r1 - r0)
            sc = 1 if c1 > c0 else -1
            sr = 1 if r1 > r0 else -1
            err = dc - dr

            c, r = c0, r0
            while True:
                # Mark as free unless this is the endpoint
                at_end = (c == c1 and r == r1)
                if at_end:
                    if hit:
                        self._set_occupied(c, r)
                    break
                else:
                    self._set_free(c, r)

                e2 = 2 * err
                if e2 > -dr:
                    err -= dr
                    c   += sc
                if e2 < dc:
                    err += dc
                    r   += sr

    def _clamp_to_grid(self, c0: int, r0: int,
                       wx_end: float, wy_end: float):
        """
        When a beam endpoint falls outside the grid, walk Bresenham
        inward and return the last valid cell. Returns None if the
        origin itself is out of bounds (shouldn't happen).
        """
        c1_f = (wx_end - GRID_X_MIN) / self._res
        r1_f = (wy_end - GRID_Y_MIN) / self._res
        # Clamp to grid boundary
        c1 = int(max(0, min(self._cols - 1, c1_f)))
        r1 = int(max(0, min(self._rows - 1, r1_f)))
        return c1, r1

    # ── Pygame visualisation ──────────────────────────────────────────────────
    def init_display(self, cell_px: int = 4):
        """
        Initialise a pygame window.  Call once from the main thread.

        Parameters
        ----------
        cell_px : pixels per grid cell (default 4 → ~520x560 window for 130x140 grid)
        """
        try:
            import pygame
            self._pygame = pygame
            self._cell_px = cell_px
            width  = self._cols * cell_px
            height = self._rows * cell_px
            pygame.init()
            self._screen = pygame.display.set_mode((width, height))
            pygame.display.set_caption("Maze 5 — Occupancy Grid")
            print(f"[occupancy_grid] Pygame display {width}x{height} px opened.")
        except ImportError:
            print("[occupancy_grid] WARNING — pygame not installed, "
                  "display disabled.")
            self._screen = None

    def render(self, robot_x=None, robot_y=None, path=None):
        """
        Draw the occupancy grid + optional robot position and planned path.
        Must be called from the main thread (pygame requirement).

        Parameters
        ----------
        robot_x/y : current robot world position (m) or None
        path      : list of (wx, wy) world waypoints or None
        """
        if self._screen is None:
            return

        pg  = self._pygame
        cpx = self._cell_px

        # ── Handle pygame quit event ──────────────────────────────────
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                self._screen = None
                return

        # ── Draw grid cells ───────────────────────────────────────────
        surf = pg.surfarray.make_surface(self._grid_to_rgb())
        # surf is (cols, rows) in pygame coords; flip row so Y=0 is bottom
        surf = pg.transform.flip(surf, False, True)
        scaled = pg.transform.scale(surf,
                                    (self._cols * cpx, self._rows * cpx))
        self._screen.blit(scaled, (0, 0))

        # ── Draw planned path ─────────────────────────────────────────
        if path:
            pts = []
            for wx, wy in path:
                cell = self.world_to_grid(wx, wy)
                if cell:
                    col, row = cell
                    # Flip row for display (Y up → Y down)
                    px = col * cpx + cpx // 2
                    py = (self._rows - 1 - row) * cpx + cpx // 2
                    pts.append((px, py))
            if len(pts) > 1:
                pg.draw.lines(self._screen, (0, 200, 255), False, pts, 2)

        # ── Draw robot position ───────────────────────────────────────
        if robot_x is not None and robot_y is not None:
            cell = self.world_to_grid(robot_x, robot_y)
            if cell:
                col, row = cell
                px = col * cpx + cpx // 2
                py = (self._rows - 1 - row) * cpx + cpx // 2
                pg.draw.circle(self._screen, (255, 80, 0), (px, py), max(3, cpx * 2))

        pg.display.flip()

    def _grid_to_rgb(self):
        """
        Three-state map rendering — inspired by discrete grid_map approach:
          OBSTACLE (inflated wall/poison) → black   (0,   0,   0)
          FREE     (lidar confirmed free) → white   (255, 255, 255)
          UNKNOWN  (never seen by lidar)  → grey    (80,  80,  80)

        Additional overlays:
          Frontier boundary               → cyan    (0,   220, 220)
          Robot path (drawn separately in render())

        Returns numpy array (cols, rows, 3) for pygame surfarray.
        """
        # ── Base: classify every cell into 3 states ───────────────────
        not_wall  = ~self._inflated_mask                      # not an obstacle
        is_free   = (self._log_odds <  0.0) & not_wall       # lidar confirmed free
        is_unknown= (self._log_odds == 0.0) & not_wall       # never seen
        is_obs    = self._inflated_mask                       # wall / poison / inflation

        # Start with grey (unknown) everywhere
        r_ch = np.full((_ROWS, _COLS), 80, dtype=np.uint8)
        g_ch = np.full((_ROWS, _COLS), 80, dtype=np.uint8)
        b_ch = np.full((_ROWS, _COLS), 80, dtype=np.uint8)

        # FREE → white
        r_ch[is_free] = 255
        g_ch[is_free] = 255
        b_ch[is_free] = 255

        # OBSTACLE → black
        r_ch[is_obs] = 0
        g_ch[is_obs] = 0
        b_ch[is_obs] = 0

        # ── Frontier overlay — cyan ────────────────────────────────────
        import cv2 as _cv2
        k4 = np.array([[0,1,0],[1,1,1],[0,1,0]], dtype=np.uint8)
        unk_dil  = _cv2.dilate(is_unknown.astype(np.uint8),
                                k4, iterations=1).astype(bool)
        frontier = is_free & unk_dil
        r_ch[frontier] = 0
        g_ch[frontier] = 220
        b_ch[frontier] = 220

        # pygame surfarray expects (cols, rows, 3)
        rgb = np.stack([r_ch.T, g_ch.T, b_ch.T], axis=2)
        return rgb

    # ── Accessors for pathfinder ──────────────────────────────────────────────
    @property
    def log_odds(self):
        """Raw log-odds numpy array (rows x cols)."""
        return self._log_odds

    @property
    def shape(self):
        return (self._rows, self._cols)

    @property
    def resolution(self):
        return self._res

    def obstacle_mask(self) -> np.ndarray:
        """
        Boolean obstacle mask for A* path planning. Shape (rows, cols).
        True = obstacle (wall / poison / inflated).
        Based on _inflated_mask — unknown space is FREE.
        """
        return self._inflated_mask

    # ── Frontier Detection + Scoring + Blacklist ─────────────────────────────
    def __init_frontier_state(self):
        """Lazy-init frontier blacklist (called from __init__ indirectly)."""
        if not hasattr(self, '_frontier_blacklist'):
            # Set of (grid_col, grid_row) centroids that A* cannot reach
            self._frontier_blacklist = set()

    def blacklist_frontier(self, wx: float, wy: float):
        """
        Mark a frontier centroid as unreachable so it is never
        returned again.  Called by the pathfinder when A* fails.

        Parameters
        ----------
        wx, wy : world coords of the frontier centroid to blacklist
        """
        self.__init_frontier_state()
        cell = self.world_to_grid(wx, wy)
        if cell:
            self._frontier_blacklist.add(cell)
            print(f"[occupancy_grid] Frontier ({wx:.2f},{wy:.2f}) blacklisted.")

    def clear_blacklist(self):
        """Clear all blacklisted frontiers (call after map update)."""
        self.__init_frontier_state()
        self._frontier_blacklist.clear()

    def _compute_frontier_mask(self):
        """
        Internal helper — returns (frontier_mask, labels, n_labels).
        Shared between get_frontiers() and frontier_count().

        Cell state definitions:
          UNKNOWN  : _log_odds == 0  AND  _inflated_mask == False
          FREE     : _log_odds <  0  AND  _inflated_mask == False
          OCCUPIED : _inflated_mask == True

        Reference: Yamauchi, B. (1997). A frontier-based approach for
        autonomous exploration. IEEE CIRA, pp. 146-151.
        """
        import cv2
        not_wall   = ~self._inflated_mask
        is_free    = (self._log_odds <  0.0) & not_wall
        is_unknown = (self._log_odds == 0.0) & not_wall

        kernel_4 = np.array([[0, 1, 0],
                              [1, 1, 1],
                              [0, 1, 0]], dtype=np.uint8)
        unknown_dil  = cv2.dilate(is_unknown.astype(np.uint8),
                                   kernel_4, iterations=1).astype(bool)
        frontier_mask = is_free & unknown_dil

        if not frontier_mask.any():
            return frontier_mask, None, 0

        n_labels, labels = cv2.connectedComponents(
            frontier_mask.astype(np.uint8), connectivity=4)
        return frontier_mask, labels, n_labels

    def get_frontiers(self, robot_x: float, robot_y: float,
                      min_size: int = 3) -> list:
        """
        Find, score, and rank frontier components.

        Scoring
        -------
        score = size / distance
          - Prefers LARGE frontiers (more unknown space to reveal)
          - Prefers NEAR frontiers  (less travel cost)
          - Blacklisted centroids are silently skipped

        Parameters
        ----------
        robot_x/y : current robot world position (m)
        min_size  : minimum frontier component size in cells

        Returns
        -------
        list of (wx, wy, size, score) tuples, best score first.
        Empty list if no reachable frontiers found.
        """
        self.__init_frontier_state()
        _, labels, n_labels = self._compute_frontier_mask()
        if n_labels == 0:
            return []

        robot_cell = self.world_to_grid(robot_x, robot_y)
        rc, rr = robot_cell if robot_cell else (0, 0)

        frontiers = []
        for label_id in range(1, n_labels):      # 0 = background
            component = (labels == label_id)
            size = int(component.sum())
            if size < min_size:
                continue

            # Centroid in grid coords
            rows_idx, cols_idx = np.where(component)
            cr = int(rows_idx.mean())
            cc = int(cols_idx.mean())

            # Skip blacklisted centroids
            if (cc, cr) in self._frontier_blacklist:
                continue

            # World coords of centroid
            wx, wy = self.grid_to_world(cc, cr)

            # Euclidean distance robot → frontier (metres)
            dist = math.hypot(cc - rc, cr - rr) * self._res
            if dist < 1e-6:
                dist = 1e-6     # avoid division by zero

            # Score: size / distance — large nearby frontiers win
            score = size / dist

            frontiers.append((wx, wy, size, score))

        # Sort by score descending — best frontier first
        frontiers.sort(key=lambda f: f[3], reverse=True)

        return frontiers   # (wx, wy, size, score)

    def frontier_count(self, min_size: int = 3) -> int:
        """Quick count of scoreable frontier components."""
        _, labels, n_labels = self._compute_frontier_mask()
        if n_labels == 0:
            return 0
        count = 0
        for label_id in range(1, n_labels):
            if int((labels == label_id).sum()) >= min_size:
                count += 1
        return count