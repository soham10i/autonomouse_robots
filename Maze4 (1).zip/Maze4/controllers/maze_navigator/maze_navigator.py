# maze_navigator.py
# Maze 4 — Full Navigation
# Single main loop — no blocking sub-loops
# START → A* → DWA → BLUE → A* → DWA → YELLOW → STOP

from controller import Robot
import settings, math, numpy as np

from config         import setup_robot
from utils          import Odometry, distance_to_goal, heading_error
from occupancy_grid import OccupancyGrid
from pathfinder     import Pathfinder
from navigator      import Navigator

print("=" * 55)
print("  MAZE 4 — Full Navigation")
print("=" * 55)

# ── Boot ──────────────────────────────────────────────────
robot    = Robot()
devices  = setup_robot(robot)
encoders = devices["encoders"]
compass  = devices["compass"]
lidar    = devices["lidar"]
odom     = Odometry()

# ── Build map + planner + navigator ──────────────────────
print("[ Init ] Building map...")
grid = OccupancyGrid()
grid.build_static_map()
print("[ Init ] Building pathfinder...")
pf   = Pathfinder(grid)
print("[ Init ] Building navigator...")
nav  = Navigator(grid, devices)
print("[ Init ] Opening display...")
grid.init_display(cell_px=4)
print("[ Init ] All ready.\n")

# ── State machine ─────────────────────────────────────────
STATE_WARMUP   = 0
STATE_PLAN1    = 1
STATE_DRIVE1   = 2
STATE_PLAN2    = 3
STATE_DRIVE2   = 4
STATE_DONE     = 5

state        = STATE_WARMUP
warmup_steps = 0
path         = []
wp_idx       = 0
stuck_count  = 0
recovery_steps = 0
RECOVERY_REVERSE = 15
RECOVERY_TURN    = 20

goal_wx, goal_wy = settings.WAYPOINT_1_X, settings.WAYPOINT_1_Y

step_num = 0

# ── Main loop ─────────────────────────────────────────────
while robot.step(settings.TIME_STEP) != -1:
    step_num += 1

    # ── Odometry + lidar every step ───────────────────────
    enc_left  = (encoders["fl"].getValue() + encoders["rl"].getValue()) / 2.0
    enc_right = (encoders["fr"].getValue() + encoders["rr"].getValue()) / 2.0
    odom.update(enc_left, enc_right, compass)

    ranges = lidar.getRangeImage()
    fov    = lidar.getFov()
    n      = lidar.getNumberOfPoints()
    angles = [fov/2.0 - i*fov/max(n-1,1) for i in range(n)]
    grid.update_from_lidar(ranges, angles, odom.x, odom.y, odom.theta)

    # ── Render every 10 steps ─────────────────────────────
    if step_num % 10 == 0:
        grid.render(odom.x, odom.y,
                    path=path[wp_idx:] if path else None)

    # ════════════════════════════════════════════════════
    # STATE MACHINE
    # ════════════════════════════════════════════════════

    # ── WARMUP: let lidar seed for 5 steps ───────────────
    if state == STATE_WARMUP:
        warmup_steps += 1
        if warmup_steps >= 5:
            print(f"[ Warmup done ] Pose: {odom}")
            state = STATE_PLAN1

    # ── PLAN1: A* from current pos → Blue ────────────────
    elif state == STATE_PLAN1:
        goal_wx, goal_wy = settings.WAYPOINT_1_X, settings.WAYPOINT_1_Y
        print(f"[ Plan ] START → BLUE ({goal_wx},{goal_wy})")
        print(f"         from ({odom.x:.3f},{odom.y:.3f})")
        print(f"         start free: {grid.is_free(odom.x, odom.y)}")
        print(f"         blue  free: {grid.is_free(goal_wx, goal_wy)}")
        path = pf.plan(odom.x, odom.y, goal_wx, goal_wy)
        if path:
            print(f"[ Plan ] Path found: {len(path)} waypoints")
            wp_idx      = 0
            stuck_count = 0
            state       = STATE_DRIVE1
        else:
            print("[ Plan ] FAIL — no path to Blue. Stopping.")
            state = STATE_DONE

    # ── DRIVE1: DWA toward Blue ───────────────────────────
    elif state == STATE_DRIVE1:
        # Check overall goal reached
        dist = distance_to_goal(odom.x, odom.y, goal_wx, goal_wy)
        if dist < settings.GOAL_RADIUS:
            nav.stop()
            print(f"[ BLUE REACHED ] dist={dist:.3f}m  pose={odom}")
            state = STATE_PLAN2
            continue

        # Advance waypoints
        if wp_idx < len(path):
            wx, wy = path[wp_idx]
            if distance_to_goal(odom.x, odom.y, wx, wy) < settings.NAV_WAYPOINT_TOLERANCE:
                wp_idx += 1
                if step_num % 50 == 0:
                    print(f"[ Drive→Blue ] wp {wp_idx}/{len(path)}, dist={dist:.2f}m")
                continue

            reached, stuck = nav.follow_waypoint(wx, wy, odom)
            if stuck:
                stuck_count += 1
                print(f"[ Stuck ] count={stuck_count}")
                if stuck_count >= 3:
                    # Replan
                    new = pf.plan(odom.x, odom.y, goal_wx, goal_wy)
                    if new:
                        path = new; wp_idx = 0; stuck_count = 0
                        print(f"[ Replan ] {len(path)} waypoints")
                    else:
                        print("[ Replan ] failed — stopping")
                        state = STATE_DONE
                else:
                    # Quick reverse
                    nav.set_velocity(-settings.MAX_SPEED*0.3,
                                     -settings.MAX_SPEED*0.3)
        else:
            # Path exhausted, replan
            new = pf.plan(odom.x, odom.y, goal_wx, goal_wy)
            if new:
                path = new; wp_idx = 0
            else:
                state = STATE_DONE

    # ── PLAN2: A* from Blue → Yellow ─────────────────────
    elif state == STATE_PLAN2:
        goal_wx, goal_wy = settings.WAYPOINT_2_X, settings.WAYPOINT_2_Y
        print(f"[ Plan ] BLUE → YELLOW ({goal_wx},{goal_wy})")
        path = pf.plan(odom.x, odom.y, goal_wx, goal_wy)
        if path:
            print(f"[ Plan ] Path found: {len(path)} waypoints")
            wp_idx = 0; stuck_count = 0
            state  = STATE_DRIVE2
        else:
            print("[ Plan ] FAIL — no path to Yellow. Stopping.")
            state = STATE_DONE

    # ── DRIVE2: DWA toward Yellow ─────────────────────────
    elif state == STATE_DRIVE2:
        dist = distance_to_goal(odom.x, odom.y, goal_wx, goal_wy)
        if dist < settings.GOAL_RADIUS:
            nav.stop()
            print(f"[ YELLOW REACHED ] dist={dist:.3f}m  pose={odom}")
            print("[ *** MISSION COMPLETE *** ]")
            state = STATE_DONE
            continue

        if wp_idx < len(path):
            wx, wy = path[wp_idx]
            if distance_to_goal(odom.x, odom.y, wx, wy) < settings.NAV_WAYPOINT_TOLERANCE:
                wp_idx += 1
                continue
            reached, stuck = nav.follow_waypoint(wx, wy, odom)
            if stuck:
                stuck_count += 1
                if stuck_count >= 3:
                    new = pf.plan(odom.x, odom.y, goal_wx, goal_wy)
                    if new:
                        path = new; wp_idx = 0; stuck_count = 0
                    else:
                        state = STATE_DONE
                else:
                    nav.set_velocity(-settings.MAX_SPEED*0.3,
                                     -settings.MAX_SPEED*0.3)
        else:
            new = pf.plan(odom.x, odom.y, goal_wx, goal_wy)
            if new:
                path = new; wp_idx = 0
            else:
                state = STATE_DONE

    # ── DONE ─────────────────────────────────────────────
    elif state == STATE_DONE:
        nav.stop()
        grid.render(odom.x, odom.y)
        # Keep pygame alive
        if grid._screen is not None:
            pg = grid._pygame
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    break

print("\n[ Exit ]")