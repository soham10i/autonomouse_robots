# config.py
# setup_robot() — initialises every device the controller needs and returns
# a single dict of handles. Raises RuntimeError if a critical device is
# missing so the caller fails fast with a clear message.
#
# Reference: Cyberbotics Webots ROSbot documentation
# https://webots.cloud/run?version=R2023b&url=https://github.com/cyberbotics/
#           webots/blob/released/projects/robots/husarion/rosbot/protos/Rosbot.proto
# Device names verified by live discovery on R2025a — June 2025
# Maze: Maze4.wbt — OTH Amberg-Weiden Autonomous Robots

from controller import Robot
from settings import TIME_STEP, MAX_SPEED

# ── Exact device names (verified on R2025a ROSbot by live discovery) ─────────
# Motors use joint names; encoders use long-form sensor names
# Lidar device: 'laser' (not 'rplidar' — confirmed by discovery script)
# Compass device: 'imu compass' (MPU-9250 IMU onboard ROSbot)

_MOTOR_NAMES = {
    "fl": "fl_wheel_joint",
    "fr": "fr_wheel_joint",
    "rl": "rl_wheel_joint",
    "rr": "rr_wheel_joint",
}

_ENCODER_NAMES = {
    "fl": "front left wheel motor sensor",
    "fr": "front right wheel motor sensor",
    "rl": "rear left wheel motor sensor",
    "rr": "rear right wheel motor sensor",
}

_LIDAR_NAME   = "laser"
_COMPASS_NAME = "imu compass"


def setup_robot(robot: Robot) -> dict:
    """
    Initialise all ROSbot devices and return a handle dictionary.

    Parameters
    ----------
    robot : controller.Robot
        The Webots Robot instance from maze_navigator.py.

    Returns
    -------
    dict with keys:
        "motors"   : dict[str, Motor]          — fl, fr, rl, rr
        "encoders" : dict[str, PositionSensor] — fl, fr, rl, rr
        "lidar"    : Lidar
        "compass"  : Compass  (or None if not found — odometry fallback)
        "timestep" : int      — simulation timestep in ms

    Raises
    ------
    RuntimeError
        If any critical device (motor, encoder, lidar) cannot be found.
        Compass is non-critical — falls back to odometry-only heading.
    """

    devices = {
        "motors":   {},
        "encoders": {},
        "lidar":    None,
        "compass":  None,
        "timestep": TIME_STEP,
    }

    # ── Motors — velocity control mode (position = inf) ───────────────────
    for key, name in _MOTOR_NAMES.items():
        motor = robot.getDevice(name)
        if motor is None:
            raise RuntimeError(
                f"[config] CRITICAL — motor '{name}' not found. "
                f"Check device names against ROSbot proto."
            )
        motor.setPosition(float("inf"))   # velocity control mode
        motor.setVelocity(0.0)            # start stopped
        devices["motors"][key] = motor

    # ── Encoders — enabled at simulation timestep ─────────────────────────
    for key, name in _ENCODER_NAMES.items():
        encoder = robot.getDevice(name)
        if encoder is None:
            raise RuntimeError(
                f"[config] CRITICAL — encoder '{name}' not found. "
                f"Check device names against ROSbot proto."
            )
        encoder.enable(TIME_STEP)
        devices["encoders"][key] = encoder

    # ── Lidar — critical for obstacle detection and map updates ───────────
    lidar = robot.getDevice(_LIDAR_NAME)
    if lidar is None:
        raise RuntimeError(
            f"[config] CRITICAL — lidar '{_LIDAR_NAME}' not found."
        )
    lidar.enable(TIME_STEP)
    lidar.enablePointCloud()
    devices["lidar"] = lidar

    # ── Compass — non-critical, corrects heading drift each timestep ──────
    compass = robot.getDevice(_COMPASS_NAME)
    if compass is None:
        print(f"[config] WARNING — compass '{_COMPASS_NAME}' not found. "
              "Heading will use odometry integration only.")
    else:
        compass.enable(TIME_STEP)
        devices["compass"] = compass

    # ── Confirmation ──────────────────────────────────────────────────────
    print("[config] setup_robot() OK  |  Maze 4")
    print(f"         motors   : {list(devices['motors'].keys())}")
    print(f"         encoders : {list(devices['encoders'].keys())}")
    print(f"         lidar    : {_LIDAR_NAME}")
    print(f"         compass  : {'OK' if devices['compass'] else 'MISSING — odometry only'}")
    print(f"         timestep : {TIME_STEP} ms")
    print(f"         max_speed: {MAX_SPEED} rad/s")

    return devices