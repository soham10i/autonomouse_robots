# pathfinder.py
# A* path planner on the OccupancyGrid.
#
# Maze: Maze4.wbt — OTH Amberg-Weiden Autonomous Robots
# Grid: 130x140 cells  (x=[-5.0,1.5], y=[-2.5,4.5], res=0.05m)
#
# Design decisions:
#   step = 1 cell  — never skips a cell, safe on thin WallShort segments
#   heuristic x1.0 — admissible octile distance, guarantees optimal path
#   wall penalty   — Gaussian convolution penalises cells near obstacles
#                    so robot naturally follows corridor centres
#
# References:
#   Hart, P.E., Nilsson, N.J., Raphael, B. (1968). A formal basis for the
#   heuristic determination of minimum cost paths. IEEE Transactions on
#   Systems Science and Cybernetics, 4(2), 100-107.
#
#   Convolution wall penalty concept adapted from:
#   Choset, H. et al. (2005). Principles of Robot Motion. MIT Press.
#   Chapter 6 — potential fields and cost maps.

import heapq
import math
import numpy as np
from settings import (
    GRID_RESOLUTION,
    GRID_X_MIN,     # -5.0  (Maze 4 — wider than Maze 5)
    GRID_Y_MIN,     # -2.5
    GRID_INFLATE_RADIUS,
    ASTAR_DIAGONAL,
)

# ── Tuning ────────────────────────────────────────────────────────────────────
_WALL_PENALTY_SIGMA  = 3      # Gaussian sigma (cells) — spread of wall cost
_WALL_PENALTY_WEIGHT = 2.0    # max extra cost added near walls
_MAX_NODES = 130 * 140        # grid cells cap — Maze 4 is 130x140 cells

# ── Move sets ─────────────────────────────────────────────────────────────────
_MOVES_4 = [(0, 1), (0, -1), (1, 0), (-1, 0)]
_MOVES_8 = _MOVES_4 + [(1, 1), (1, -1), (-1, 1), (-1, -1)]
_COST_STRAIGHT = 1.0
_COST_DIAGONAL = math.sqrt(2)


class Pathfinder:
    """
    A* planner on the OccupancyGrid for Maze 4.

    Grid covers x=[-5.0, 1.5] y=[-2.5, 4.5] at 0.05 m/cell (130x140 cells).
    Maze 4 has both WallShort (0.5m) and WallMedium (1.0m) segments —
    step=1 cell ensures no wall is skipped even at thinnest passages.

    Usage
    -----
        pf   = Pathfinder(grid)
        path = pf.plan(start_wx, start_wy, goal_wx, goal_wy)
        # returns [(wx, wy), ...] or [] if unreachable
    """

    def __init__(self, grid):
        """
        Parameters
        ----------
        grid : OccupancyGrid — already initialised with build_static_map()
        """
        self._grid         = grid
        self._rows, self._cols = grid.shape
        self._res          = grid.resolution

        # Build wall penalty layer once at startup
        self._penalty = self._build_wall_penalty()

        print(f"[pathfinder] Pathfinder ready — Maze 4")
        print(f"             grid {self._cols}x{self._rows} cells")
        print(f"             diagonal={'ON' if ASTAR_DIAGONAL else 'OFF'}")
        print(f"             wall_penalty_weight={_WALL_PENALTY_WEIGHT}")
        print(f"             node_cap={_MAX_NODES}")

    # ── Wall penalty layer ────────────────────────────────────────────────────
    def _build_wall_penalty(self) -> np.ndarray:
        """
        Gaussian blur over obstacle mask → cost layer.
        Cells close to walls get higher A* traversal cost,
        pushing planned paths toward corridor centres.

        Gaussian filter reference:
        scipy.ndimage.gaussian_filter — standard image processing tool.

        Returns float32 array (rows, cols) in [0, _WALL_PENALTY_WEIGHT].
        """
        from scipy.ndimage import gaussian_filter
        obs     = self._grid.obstacle_mask().astype(np.float32)
        blurred = gaussian_filter(obs, sigma=_WALL_PENALTY_SIGMA)
        mx      = blurred.max()
        if mx > 0:
            blurred /= mx
        penalty = (blurred * _WALL_PENALTY_WEIGHT).astype(np.float32)
        print(f"[pathfinder] Wall penalty built "
              f"(sigma={_WALL_PENALTY_SIGMA}, max={penalty.max():.2f})")
        return penalty

    def rebuild_penalty(self):
        """Rebuild penalty after map update (e.g. new lidar detections)."""
        self._penalty = self._build_wall_penalty()

    # ── Coordinate conversion ─────────────────────────────────────────────────
    def _w2g(self, wx: float, wy: float):
        """World (m) → (col, row). Returns None if out of bounds."""
        col = int((wx - GRID_X_MIN) / self._res)
        row = int((wy - GRID_Y_MIN) / self._res)
        if 0 <= col < self._cols and 0 <= row < self._rows:
            return col, row
        return None

    def _g2w(self, col: int, row: int):
        """Grid (col, row) → world centre (wx, wy) in metres."""
        wx = GRID_X_MIN + (col + 0.5) * self._res
        wy = GRID_Y_MIN + (row + 0.5) * self._res
        return wx, wy

    # ── Admissible heuristic ──────────────────────────────────────────────────
    def _heuristic(self, col: int, row: int, gc: int, gr: int) -> float:
        """
        Octile distance — admissible for 8-connected grid (x1.0 multiplier).
        Never overestimates true cost → A* returns optimal path.
        Falls back to Manhattan distance for 4-connected grid.
        """
        dc = abs(col - gc)
        dr = abs(row - gr)
        if ASTAR_DIAGONAL:
            return _COST_DIAGONAL * min(dc, dr) + _COST_STRAIGHT * abs(dc - dr)
        return _COST_STRAIGHT * (dc + dr)

    # ── A* search ────────────────────────────────────────────────────────────
    def plan(self, start_wx: float, start_wy: float,
             goal_wx: float,  goal_wy: float) -> list:
        """
        Run A* from start to goal in world coordinates.

        Parameters
        ----------
        start_wx/wy : robot current world position (m)
        goal_wx/wy  : target world position (m)

        Returns
        -------
        list of (wx, wy) world-coord waypoints, start → goal.
        Empty list if goal is unreachable or out of grid.
        """
        sc      = self._w2g(start_wx, start_wy)
        gc_goal = self._w2g(goal_wx,  goal_wy)

        if sc is None:
            print(f"[pathfinder] Start ({start_wx:.2f},{start_wy:.2f}) "
                  "out of grid — check GRID_X/Y_MIN/MAX in settings.py")
            return []
        if gc_goal is None:
            print(f"[pathfinder] Goal ({goal_wx:.2f},{goal_wy:.2f}) "
                  "out of grid — check GRID_X/Y_MIN/MAX in settings.py")
            return []

        sc_col, sc_row = sc
        gc_col, gc_row = gc_goal
        obs   = self._grid.obstacle_mask()
        pen   = self._penalty
        moves = _MOVES_8 if ASTAR_DIAGONAL else _MOVES_4

        # ── Nudge start/goal if inside obstacle ───────────────────────
        if obs[sc_row, sc_col]:
            print(f"[pathfinder] Start in obstacle — nudging...")
            sc_col, sc_row = self._nearest_free(sc_col, sc_row, obs)
            if sc_col is None:
                return []

        if obs[gc_row, gc_col]:
            print(f"[pathfinder] Goal in obstacle — nudging...")
            gc_col, gc_row = self._nearest_free(gc_col, gc_row, obs)
            if gc_col is None:
                return []

        # ── Initialise A* ─────────────────────────────────────────────
        g_cost = np.full((self._rows, self._cols), np.inf, dtype=np.float32)
        g_cost[sc_row, sc_col] = 0.0
        came_from  = {}
        open_list  = [(self._heuristic(sc_col, sc_row, gc_col, gc_row),
                       0.0, sc_col, sc_row)]
        n_expanded = 0

        # ── Search ────────────────────────────────────────────────────
        while open_list:
            f, g, col, row = heapq.heappop(open_list)

            if g > g_cost[row, col] + 1e-6:
                continue   # stale entry

            n_expanded += 1
            if n_expanded > _MAX_NODES:
                print(f"[pathfinder] Node cap {_MAX_NODES} reached — "
                      "no path. Check wall data or POISON_MARGIN.")
                return []

            # ── Goal reached ──────────────────────────────────────────
            if col == gc_col and row == gc_row:
                cells = self._reconstruct(came_from,
                                          gc_col, gc_row,
                                          sc_col, sc_row)
                path  = self._smooth_and_convert(cells)
                print(f"[pathfinder] Path found — "
                      f"{len(cells)} cells → {len(path)} waypoints, "
                      f"{n_expanded} nodes expanded.")
                return path

            # ── Expand neighbours ─────────────────────────────────────
            for dc, dr in moves:
                nc, nr = col + dc, row + dr
                if not (0 <= nc < self._cols and 0 <= nr < self._rows):
                    continue
                if obs[nr, nc]:
                    continue
                step_cost = (_COST_DIAGONAL if (dc and dr)
                             else _COST_STRAIGHT)
                new_g = g + step_cost + pen[nr, nc]
                if new_g < g_cost[nr, nc]:
                    g_cost[nr, nc]      = new_g
                    came_from[(nc, nr)] = (col, row)
                    h = self._heuristic(nc, nr, gc_col, gc_row)
                    heapq.heappush(open_list, (new_g + h, new_g, nc, nr))

        print(f"[pathfinder] No path: "
              f"({start_wx:.2f},{start_wy:.2f}) → "
              f"({goal_wx:.2f},{goal_wy:.2f}), "
              f"{n_expanded} nodes expanded.")
        return []

    # ── Path reconstruction ───────────────────────────────────────────────────
    def _reconstruct(self, came_from: dict,
                     gc: int, gr: int, sc: int, sr: int) -> list:
        """Walk came_from back to start. Returns [(col, row), ...]."""
        path, cur = [], (gc, gr)
        while cur != (sc, sr):
            path.append(cur)
            cur = came_from[cur]
        path.append((sc, sr))
        path.reverse()
        return path

    # ── Path smoothing ────────────────────────────────────────────────────────
    def _smooth_and_convert(self, path_cells: list) -> list:
        """
        1. Keep only direction-change cells (prune collinear runs).
        2. Convert remaining (col, row) cells to world (wx, wy).

        Maze 4 note: WallShort segments create tighter turns —
        direction-change pruning keeps enough waypoints for
        the navigator to steer cleanly through narrow bends.
        """
        if not path_cells:
            return []
        if len(path_cells) == 1:
            return [self._g2w(*path_cells[0])]

        # Keep first, last, and direction-change cells
        pruned = [path_cells[0]]
        for i in range(1, len(path_cells) - 1):
            pc, pr = path_cells[i - 1]
            cc, cr = path_cells[i]
            nc, nr = path_cells[i + 1]
            if (cc - pc, cr - pr) != (nc - cc, nr - cr):
                pruned.append(path_cells[i])
        pruned.append(path_cells[-1])

        return [self._g2w(c, r) for c, r in pruned]

    # ── Nearest free cell ─────────────────────────────────────────────────────
    def _nearest_free(self, col: int, row: int,
                      obs: np.ndarray, max_r: int = 8):
        """
        BFS outward from (col, row) to find nearest free cell.
        max_r increased to 8 for Maze 4 (WallShort segments can
        cluster tightly near goal areas).

        Returns (col, row) or (None, None) if not found.
        """
        from collections import deque
        q       = deque([(col, row, 0)])
        visited = {(col, row)}
        while q:
            c, r, d = q.popleft()
            if d > max_r:
                return None, None
            if not obs[r, c]:
                return c, r
            for dc, dr in _MOVES_8:
                nc, nr = c + dc, r + dr
                if ((nc, nr) not in visited and
                        0 <= nc < self._cols and 0 <= nr < self._rows):
                    visited.add((nc, nr))
                    q.append((nc, nr, d + 1))
        return None, None