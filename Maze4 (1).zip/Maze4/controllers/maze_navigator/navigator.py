# navigator.py
# Motion control: DWA (Dynamic Window Approach) + path following
# Adapted from friend's approach — different variable names, our pipeline structure,
# integrated with our OccupancyGrid and Odometry instead of Supervisor API.
#
# Reference for DWA algorithm:
# Fox, D., Burgard, W., Thrun, S. (1997). The dynamic window approach to collision
# avoidance. IEEE Robotics & Automation Magazine, 4(1), 23-33.
#
# Concept reference (adapted, not copied):
# Friend's my_robot.py dwa_planner() and follow_local_target() — OTH Amberg-Weiden 2025

import math
import numpy as np
from settings import (
    MAX_SPEED, WHEEL_RADIUS, AXLE_LENGTH, TIME_STEP,
    NAV_WAYPOINT_TOLERANCE, GRID_X_MIN, GRID_Y_MIN, GRID_RESOLUTION,
)

# ── DWA tuning ────────────────────────────────────────────────────────────────
# Velocity samples (m/s) — forward speed candidates
_V_SAMPLES = [0.05, 0.10, 0.15, 0.20, 0.30, 0.40]

# Angular velocity samples (rad/s) — turning rate candidates
_W_SAMPLES = [0.0, 1.5, -1.5, 2.5, -2.5, 3.5, -3.5, 4.5, -4.5]

# DWA scoring weights
_W_HEADING  = 4.0    # reward facing the target
_W_DISTANCE = 3.5    # reward being close to target
_W_SPEED    = 0.05   # reward moving fast

# Prediction horizon (timesteps to simulate each v/w combo)
_DWA_HORIZON = 2

# Max distance increase allowed during prediction (m) — stops DWA going wrong way
_DWA_MAX_DIST_INCREASE = 0.20

# Stuck detection
_STUCK_MOVE_THRESHOLD = 0.005   # m — less than this = not moving
_STUCK_COUNT_LIMIT    = 25      # consecutive non-moving calls → declare stuck

# Waypoint reach tolerance
_REACH_DIST_M = NAV_WAYPOINT_TOLERANCE   # m


class Navigator:
    """
    DWA-based local motion controller for the ROSbot.

    Works in world coordinates (metres) using odometry pose.
    Queries OccupancyGrid.obstacle_mask() for collision prediction.

    Usage
    -----
        nav = Navigator(grid, devices)

        # each timestep:
        reached, stuck = nav.follow_waypoint(wx, wy, odom)
        # reached=True → move to next waypoint
        # stuck=True   → trigger recovery
    """

    def __init__(self, grid, devices: dict):
        """
        Parameters
        ----------
        grid    : OccupancyGrid — for obstacle queries during DWA prediction
        devices : dict from config.setup_robot() — needs 'motors'
        """
        self._grid    = grid
        self._motors  = devices["motors"]
        self._dt      = TIME_STEP / 1000.0   # seconds per timestep

        # Stuck detection state
        self._stuck_count    = 0
        self._last_pos       = None

        print("[navigator] Navigator ready — DWA motion control")
        print(f"            v_samples={_V_SAMPLES}")
        print(f"            w_samples={len(_W_SAMPLES)} values")
        print(f"            reach_tolerance={_REACH_DIST_M:.2f}m")

    # ── Public interface ──────────────────────────────────────────────────────
    def follow_waypoint(self, wx: float, wy: float, odom) -> tuple:
        """
        Drive toward world waypoint (wx, wy) using DWA for one timestep.

        Parameters
        ----------
        wx, wy : float — target world coordinates (m)
        odom   : Odometry — current robot pose

        Returns
        -------
        (reached: bool, stuck: bool)
            reached=True  → within NAV_WAYPOINT_TOLERANCE of target
            stuck=True    → robot not moving, trigger recovery
        """
        dist = math.hypot(wx - odom.x, wy - odom.y)

        # ── Check reached ─────────────────────────────────────────────
        if dist < _REACH_DIST_M:
            self._stuck_count = 0
            self._last_pos    = None
            self.stop()
            return True, False

        # ── Stuck detection ───────────────────────────────────────────
        cur_pos = np.array([odom.x, odom.y])
        if self._last_pos is not None:
            moved = float(np.linalg.norm(cur_pos - self._last_pos))
            if moved < _STUCK_MOVE_THRESHOLD:
                self._stuck_count += 1
            else:
                self._stuck_count = 0
        self._last_pos = cur_pos

        if self._stuck_count >= _STUCK_COUNT_LIMIT:
            self._stuck_count = 0
            self._last_pos    = None
            self.stop()
            return False, True

        # ── DWA planning ──────────────────────────────────────────────
        v, w = self._dwa(wx, wy, odom)
        lw, rw = self._to_wheel_speeds(v, w)
        self._set_motors(lw, rw)
        return False, False

    def stop(self):
        """Set all motors to zero velocity."""
        for motor in self._motors.values():
            motor.setVelocity(0.0)

    def set_velocity(self, left_speed: float, right_speed: float):
        """Directly set left/right wheel speeds (rad/s)."""
        self._motors["fl"].setVelocity(left_speed)
        self._motors["fr"].setVelocity(right_speed)
        self._motors["rl"].setVelocity(left_speed)
        self._motors["rr"].setVelocity(right_speed)

    def reverse(self, steps: int = 20):
        """
        Drive backward for N timesteps.
        Called by recovery behavior in maze_navigator.py.
        """
        self._set_motors(-MAX_SPEED * 0.5, -MAX_SPEED * 0.5)

    def reset_stuck(self):
        """Reset stuck counter — call after recovery."""
        self._stuck_count = 0
        self._last_pos    = None

    # ── DWA core ─────────────────────────────────────────────────────────────
    def _dwa(self, target_wx: float, target_wy: float, odom) -> tuple:
        """
        Dynamic Window Approach — samples (v, w) combinations,
        simulates each trajectory, scores by heading/distance/speed.

        Parameters
        ----------
        target_wx/wy : world target position (m)
        odom         : current Odometry pose

        Returns
        -------
        (v, w) : best linear (m/s) and angular (rad/s) velocity
        """
        best_score = -float("inf")
        best_v, best_w = 0.0, 0.0

        x, y, theta = odom.x, odom.y, odom.theta
        current_dist = math.hypot(target_wx - x, target_wy - y)
        dt = self._dt

        for v in _V_SAMPLES:
            for w in _W_SAMPLES:
                # ── Simulate trajectory ───────────────────────────────
                cx, cy, ct = x, y, theta
                valid = True

                for _ in range(_DWA_HORIZON):
                    cx += v * math.cos(ct) * dt
                    cy += v * math.sin(ct) * dt
                    ct += w * dt

                    # Collision check on inflated obstacle mask
                    if self._grid.obstacle_mask() is not None:
                        cell = self._world_to_grid(cx, cy)
                        if cell and self._grid.obstacle_mask()[cell[1], cell[0]]:
                            valid = False
                            break

                    # Check moving away from target
                    pred_dist = math.hypot(target_wx - cx, target_wy - cy)
                    if pred_dist - current_dist > _DWA_MAX_DIST_INCREASE:
                        valid = False
                        break

                if not valid:
                    continue

                # ── Score this trajectory ─────────────────────────────
                pred_angle  = math.atan2(target_wy - cy, target_wx - cx)
                heading_err = _wrap_angle(pred_angle - ct)
                pred_dist   = math.hypot(target_wx - cx, target_wy - cy)

                heading_score  = math.cos(heading_err)
                distance_score = 1.0 - (pred_dist / max(current_dist, 0.01))
                speed_score    = v / (MAX_SPEED * WHEEL_RADIUS)

                score = (_W_HEADING  * heading_score +
                         _W_DISTANCE * distance_score +
                         _W_SPEED    * speed_score)

                if score > best_score:
                    best_score = score
                    best_v, best_w = v, w

        return best_v, best_w

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _to_wheel_speeds(self, v: float, w: float) -> tuple:
        """
        Convert linear (m/s) + angular (rad/s) to left/right wheel speeds (rad/s).
        Differential drive kinematics.
        """
        v_left  = (v - w * AXLE_LENGTH / 2.0) / WHEEL_RADIUS
        v_right = (v + w * AXLE_LENGTH / 2.0) / WHEEL_RADIUS
        # Clamp to motor limits
        limit   = MAX_SPEED
        v_left  = max(-limit, min(limit, v_left))
        v_right = max(-limit, min(limit, v_right))
        return v_left, v_right

    def _set_motors(self, left: float, right: float):
        """Apply left/right wheel speeds to all four motors."""
        self._motors["fl"].setVelocity(left)
        self._motors["rl"].setVelocity(left)
        self._motors["fr"].setVelocity(right)
        self._motors["rr"].setVelocity(right)

    def _world_to_grid(self, wx: float, wy: float):
        """World → (col, row) for obstacle mask query."""
        col = int((wx - GRID_X_MIN) / GRID_RESOLUTION)
        row = int((wy - GRID_Y_MIN) / GRID_RESOLUTION)
        rows, cols = self._grid.shape
        if 0 <= col < cols and 0 <= row < rows:
            return col, row
        return None


def _wrap_angle(angle: float) -> float:
    """Normalise angle to [-pi, pi]."""
    return math.atan2(math.sin(angle), math.cos(angle))