# Maze4 — ROSbot Maze Navigator (Webots)

> **Working log** — updated every session so we stay in sync.

---

## What this project is

A Webots simulation of a differential-drive robot (ROSbot) that autonomously explores a maze, avoids a lethal green-carpet zone, locates a **blue pillar** (start) and a **yellow pillar** (end), then drives the final path between them.

---

## Repo layout

```
Maze4/
├── worlds/
│   └── Maze4.wbt               # Webots world file (maze + robot)
├── protos/
│   ├── WallLong.proto
│   ├── WallMedium.proto
│   └── WallShort.proto         # Custom wall shapes used in the world
├── controllers/
│   └── maze_navigator/         # OUR working controller (Khushi)
│       └── settings.py         # All tunable constants (see below)
├── controllers_Arman/
│   └── maze_navigator/         # Arman's reference implementation (read-only reference)
│       ├── CONSTANTS.py
│       ├── maze_navigator.py   # Entry point (pygame display + main loop)
│       ├── my_robot.py
│       ├── map.py
│       ├── astar_2_spline.py
│       └── utils.py
├── libraries/                  # (empty — reserved for shared libs)
└── plugins/                    # (empty — Webots plugin stubs)
```

---

## Our controller (`controllers/maze_navigator/`)

### Current state

| File | Status | Purpose |
|---|---|---|
| `settings.py` | ✅ Done | Central config — all magic numbers live here |
| *(everything else)* | 🔲 To build | Deleted old stubs; building fresh from scratch |

### Architecture plan (modules to write next)

We are building a clean, modular controller split across focused files — no monolithic script.

| File (to create) | Responsibility |
|---|---|
| `maze_navigator.py` | Entry point — Webots `while robot.step()` loop |
| `robot_io.py` | Motor commands, sensor reads (lidar, camera, depth) |
| `odometry.py` | Wheel encoder → pose (x, y, θ) |
| `grid_2d.py` | 300×300 log-odds occupancy grid |
| `perception.py` | HSV colour detection (blue / yellow / green pillars) |
| `explorer.py` | Frontier-based exploration |
| `planning.py` | A* path planning with inflation fallback |
| `local_control.py` | Pure-pursuit / PID heading controller |
| `fsm.py` | High-level finite state machine (EXPLORE → SEEK → FOLLOW → DONE) |
| `recovery.py` | Stuck detection & reverse-turn recovery |
| `clearance.py` | Obstacle inflation around green carpet |

---

## Key settings (`settings.py`)

All values are in SI units (metres, radians, seconds) unless noted.

| Group | Key constants |
|---|---|
| Simulation | `TIME_STEP=32 ms`, `MAX_WHEEL_SPEED=10 rad/s` |
| Robot geometry | `WHEEL_RADIUS=0.043 m`, `AXLE_LENGTH=0.18 m` |
| Grid | `300×300 cells`, `CELL_SIZE≈0.033 m/cell` |
| Log-odds | hit `+0.85`, miss `−0.40`, clamp `[−5, +5]`, threshold `0.65` |
| Inflation | `INFLATION_RADIUS=5 cells` (normal), `POISON_INFLATE=8 cells` (green) |
| Lidar | range `0.05–3.5 m`, noise filter on |
| Colour HSV | Blue `H 100–140`, Yellow `H 20–35`, Green `H 36–86` |
| A* | heuristic weight `1.2`, inflation sequence `[5,3,2,1]` |
| Path following | waypoint spacing `10`, lookahead `0.25 m` |
| Motion | forward `4 rad/s`, turn `3 rad/s`, slow `2 rad/s`, back `−3 rad/s` |
| Heading PID | Kp `5.0`, Ki `0.0`, Kd `0.5` |
| Recovery | stuck check every `20 steps`, reverse `15 steps`, turn `25 steps` |
| Mission | pillar reach `0.40 m`, standoff `0.35 m`, confirm count `5` |

---
**Fixed (sixth run — four structural problems):**
- **Problem 1 — A* hammering unreachable frontiers**: `_select_frontier()` now blacklists any frontier that fails A* with all inflation levels immediately (`chosen_frontiers.add`). Capped at 5 attempts per selection cycle. Full replan now happens every `FRONTIER_REPLAN_EVERY=50` steps instead of every 8.
- **Problem 2 — Robot stalls after first frontier**: `_select_frontier()` falls back through inflation levels `[full → 3 cells → 1 cell]` before giving up. Thin-corridor frontiers that fail full inflation now still get a path.
- **Problem 3 — Duplicate main loop**: `maze_navigator.py` was running its own `while robot.step()` loop alongside `Navigator.run()`. Collapsed to a single entry: `robot.run(screen=screen)`. `Navigator.run()` now accepts `screen=None` and calls `_update_display(screen)` each step. `maze_navigator.py` is now 20 lines.
- **Problem 4 — Speed**: `DWA_VELOCITY_SAMPLES` updated to `[0.3, 0.4, 0.5, 0.6, 0.8]` m/s. `DRIVE_SPEED_SLOW` was already `6.0`.

**Fixed (fifth run — "Start cell is blocked" spam, exploration stalls):**
- Robot explored two frontiers successfully, then odometry drift placed its estimated grid cell inside an inflated obstacle zone → every A* call failed immediately with "Start cell is blocked" from `(78, 236)`.
- Added `_nearest_free(grid, col, row, max_radius=8)` helper in `pathfinder.py`: spirals outward from a blocked start/goal and returns the nearest unblocked cell within 8 cells.
- `find_path()` now uses this fallback for both start and goal before bailing — handles odometry-drift-near-wall without reducing inflation safety margin.

**Fixed (fourth run — persistent RuntimeWarning in `world_to_grid`):**
- **Encoder NaN in `__init__`** (`navigator.py:78–83`): `_read_encoders()` called before first `step()`, so sensors may return NaN. `prev_enc_left/right` became NaN → `delta_left = valid - NaN = NaN` → `self.x += NaN` → position corrupted. Fixed with `isfinite` guard, defaulting to `0.0` when not ready.
- **`world_to_grid` NaN guard** (`utils.py:51`): added `isfinite` check at the top of the function so any non-finite coordinate silently returns `None` (no RuntimeWarning, all callers already handle `None`).

**Fixed (second run — infinite "Exploration complete — map saturated" loop):**

Root cause chain: compass returns NaN for the first few simulation steps. Because `0.0 * math.cos(NaN) = NaN` in Python, even with zero movement the robot position `(x, y)` became NaN. Every downstream call — `detect_frontiers(NaN, NaN)` and `world_to_grid(NaN, ...)` — returned `None`/`[]`, so no frontiers were ever found and the map could never be updated.

Two bugs fixed:
- **Compass NaN guard** (`navigator.py:184–188`): if `_read_compass()` returns NaN (sensor not ready), fall back to encoder dead-reckoning (`self.heading += delta_heading`) instead of assigning NaN to heading. Once the compass is ready it takes over automatically.
- **Frontier centroid col/row swap** (`occupancy_grid.py:299`): `cy, cx = centroids[label]` then used `(cx, cy)` — silently produced `(row, col)` instead of `(col, row)` for every frontier target. Fixed to `cx, cy = centroids[label]`.

**Fixed (third run — circular import crash):**
- **`utils.py` was accidentally overwritten** with `navigator.py` content, making it import from `occupancy_grid`, which imports from `utils` — circular. Restored `utils.py` to its correct utility-functions content (only imports from `settings`, no cross-module dependency).
- **Re-applied compass NaN guard** in `navigator.py:_update_odometry` (reverted by linter): fall back to `heading += delta_heading` when compass returns NaN.
- **Re-applied image reshape fix** in `navigator.py:_detect_pillars` (reverted by linter): `reshape((H, W, 3))` not `(H, W, 4)`.
- **Re-applied heading init fix** in `navigator.py:__init__` (reverted by linter): default `0.0` instead of reading compass before first `step()`.

**Fixed (runtime bugs on first run):**
- **`ValueError: cannot reshape array of size 921600 into shape (480,640,4)`** — Webots `getImageArray()` returns 3-channel RGB, not 4-channel RGBA. Changed reshape from `(H, W, 4)` → `(H, W, 3)` and removed the now-redundant `[:, :, :3]` slice. (`navigator.py:251`)
- **`heading=nan°` + RuntimeWarning in `world_to_grid`** — compass was read in `__init__` before any `step()` call, so sensor wasn't polled yet. Defaulted heading to `0.0`; it gets overwritten on the first `_update_odometry()` call. (`navigator.py:75`)

---

