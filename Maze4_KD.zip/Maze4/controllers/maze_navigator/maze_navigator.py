from controller import Robot
import math

robot    = Robot()
timestep = 32

motors = {
    'fl': robot.getDevice("fl_wheel_joint"),
    'fr': robot.getDevice("fr_wheel_joint"),
    'rl': robot.getDevice("rl_wheel_joint"),
    'rr': robot.getDevice("rr_wheel_joint"),
}
for m in motors.values():
    m.setPosition(float('inf'))
    m.setVelocity(0.0)

compass  = robot.getDevice("imu compass")
lidar    = robot.getDevice("laser")
compass.enable(timestep)
lidar.enable(timestep)
lidar.enablePointCloud()

encoders = {
    'fl': robot.getDevice("front left wheel motor sensor"),
    'fr': robot.getDevice("front right wheel motor sensor"),
    'rl': robot.getDevice("rear left wheel motor sensor"),
    'rr': robot.getDevice("rear right wheel motor sensor"),
}
for e in encoders.values():
    e.enable(timestep)

WHEEL_RADIUS  = 0.043
FORWARD_SPEED = 6.0
TURN_SPEED    = 3.0
OBSTACLE_DIST = 0.30

x       = -2.228
y       =  2.795
heading =  math.radians(150.0)
prev_l  = 0.0
prev_r  = 0.0

def get_heading():
    vals = compass.getValues()
    hdg  = math.atan2(vals[0], vals[1])
    return hdg if math.isfinite(hdg) else heading

def angle_diff(a, b):
    d = a - b
    while d >  math.pi: d -= 2 * math.pi
    while d < -math.pi: d += 2 * math.pi
    return d

def update_odometry():
    global x, y, heading, prev_l, prev_r
    heading   = get_heading()
    left_now  = (encoders['fl'].getValue() + encoders['rl'].getValue()) / 2.0
    right_now = (encoders['fr'].getValue() + encoders['rr'].getValue()) / 2.0
    dl = (left_now  - prev_l) * WHEEL_RADIUS
    dr = (right_now - prev_r) * WHEEL_RADIUS
    prev_l = left_now
    prev_r = right_now
    x += ((dl + dr) / 2.0) * math.cos(heading)
    y += ((dl + dr) / 2.0) * math.sin(heading)

def get_ranges():
    return list(lidar.getRangeImage())

def get_front_dist(ranges):
    n    = len(ranges)
    cone = n // 12
    mid  = n // 2
    vals = [r for r in ranges[mid-cone:mid+cone] if 0.05 < r < 3.5]
    return min(vals) if vals else 3.5

def best_open_heading(ranges, blacklist):
    n       = len(ranges)
    cur_hdg = get_heading()
    fov     = lidar.getFov()
    candidates = []
    for sector in range(12):
        start = sector * (n // 12)
        end   = start + (n // 12)
        vals  = [r for r in ranges[start:end] if 0.05 < r < 3.5]
        avg   = sum(vals) / len(vals) if vals else 0.0
        sector_angle = (sector / 12) * fov
        world_hdg    = cur_hdg - fov/2 + sector_angle
        world_hdg    = math.atan2(math.sin(world_hdg), math.cos(world_hdg))
        blacklisted  = any(
            abs(angle_diff(world_hdg, b)) < math.radians(30)
            for b in blacklist)
        if not blacklisted:
            candidates.append((avg, world_hdg))
    if not candidates:
        blacklist.clear()
        return best_open_heading(ranges, blacklist)
    candidates.sort(reverse=True)
    return candidates[0][1], candidates[0][0]

STATE_DRIVE     = 'DRIVE'
STATE_TURN      = 'TURN'
STATE_DRIVE_MIN = 'DRIVE_MIN'

state           = STATE_DRIVE
target_hdg      = get_heading()
blacklist       = []
min_drive_steps = 0
last_turn_hdg   = None
dist_driven     = 0.0

print("[Step9] Reactive navigation with position tracking")

step = 0
while robot.step(timestep) != -1:
    step += 1
    update_odometry()
    ranges = get_ranges()
    front  = get_front_dist(ranges)

    if state == STATE_DRIVE:
        if front < OBSTACLE_DIST:
            if last_turn_hdg is not None and dist_driven < 0.10:
                blacklist.append(last_turn_hdg)
                if len(blacklist) > 6:
                    blacklist.pop(0)
            target_hdg, open_dist = best_open_heading(ranges, blacklist)
            last_turn_hdg = target_hdg
            dist_driven   = 0.0
            state         = STATE_TURN
            print("[Step9] step={} pos=({:.2f},{:.2f}) Wall {:.2f}m → {:.1f}°".format(
                step, x, y, front, math.degrees(target_hdg)))
        else:
            dist_driven += 0.001
            motors['fl'].setVelocity(FORWARD_SPEED)
            motors['rl'].setVelocity(FORWARD_SPEED)
            motors['fr'].setVelocity(FORWARD_SPEED)
            motors['rr'].setVelocity(FORWARD_SPEED)

    elif state == STATE_TURN:
        err = angle_diff(target_hdg, heading)
        if abs(err) < 0.08:
            state           = STATE_DRIVE_MIN
            min_drive_steps = step + 60
            dist_driven     = 0.0
        else:
            turn = TURN_SPEED * (1.0 if err > 0 else -1.0)
            motors['fl'].setVelocity(-turn)
            motors['rl'].setVelocity(-turn)
            motors['fr'].setVelocity( turn)
            motors['rr'].setVelocity( turn)

    elif state == STATE_DRIVE_MIN:
        if front < 0.15:
            state = STATE_DRIVE
        elif step >= min_drive_steps:
            state = STATE_DRIVE
        else:
            motors['fl'].setVelocity(FORWARD_SPEED)
            motors['rl'].setVelocity(FORWARD_SPEED)
            motors['fr'].setVelocity(FORWARD_SPEED)
            motors['rr'].setVelocity(FORWARD_SPEED)

    if step % 200 == 0:
        print("[Step9] step={} pos=({:.2f},{:.2f}) heading={:.1f}° front={:.2f}m state={}".format(
            step, x, y, math.degrees(heading), front, state))

    if step >= 3000:
        for m in motors.values():
            m.setVelocity(0.0)
        print("[Step9] Done — final pos=({:.2f},{:.2f})".format(x, y))
        break